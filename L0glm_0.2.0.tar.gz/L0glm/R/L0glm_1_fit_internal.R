# Internal helper function with the core modified IRLS L0glm algorithm
#
# The weighted least square step of the standard IRLS Fisher-scoring based
# GLM algorithm is replaced with a weighted least square regression with
# adaptive ridge penalty (as in Frommlet & Nuel 2016, but also estimating
# the correct dispersion multiplier in the ridge penalty, and using
# Fisher scoring instead of Newton-Raphson, plus adding provisions for
# nonnegativity or box constraints).
#
#  Fits a generalized linear model with L0 regularization and option for
#  nonnegativity and box constraints. It takes as input parameters the design
#  matrix X, the response variable y, regularization parameters, solver options,
#  and control parameters. The result is a fitted model with coefficients
#  estimated using the specified regularization method and solver. The function
#  it is called by the higher level \code{L0glm.fit}.
#
L0glm.fit.internal = function(X, 
                              y, 
                              family = poisson(identity),
                              weights = rep(1, ncol(X)),
                              start = NULL,
                              dispersion = NULL,
                              offset = rep(0, nrow(X)),
                              lambda = 1, 
                              no.pen = 0,
                              nonnegative = FALSE,
                              normalize = TRUE,
                              solver = "eigen", 
                              method = 7L, 
                              lower = rep(-.Machine$double.xmax, ncol(X)),
                              upper = rep(.Machine$double.xmax, ncol(X)),
                              maxit = 25,
                              warm.start = 0.9,
                              prior.mean = NULL,
                              gamma = 2,
                              thresh = 1e-5,
                              tol = 1E-10,
                              control.solver = do.call("control.solver.gen", list(solver = solver, method = method)),
                              verbose = FALSE) { 

  
  # NOTE currently I haven't implemented any SCREENING RULES like
  # http://proceedings.mlr.press/v119/atamturk20a/atamturk20a.pdf
  # or sure independent screening prescreening, as implemented in abess
  # https://cran.r-project.org/web/packages/abess/abess.pdf
  # Implementing these might further speed up the algo.
  
  # Normalize columns of X to unit L2 norm? If so, calculate scaling
  if(normalize) { scaling = scaleX(X) } else { # L2 norm of columns of X
                  scaling = rep(1, ncol(X)) }
  
  if (!is.null(start)) { if (sum(start==0)==length(start)) start = NULL } # interpret all zero start values as start values still requiring initialisation

  dispersion_init = dispersion # if NULL dispersion will be estimated, except for binomial & poisson where it is 1
  if (family$family %in% c("binomial", "poisson")) { dispersion_init <- 1 }
  if (is.null(dispersion)) { dispersion <- 1 }

  if (!is(family, "family")) family = family()
  variance = family$variance # variance function for given family
  linkinv = family$linkinv # inverse link function
  link = family$linkfun # link function
  init = family$initialize # initialisation function
  dev.resids = family$dev.resids # deviance residuals function
  mu.eta = family$mu.eta # function of derivative of the expected values
  
  if (!is.function(variance) || !is.function(linkinv) )
    stop("'family' argument seems not to be a valid family object", call. = FALSE)

  etastart = NULL
  mustart = NULL
  n = NULL
  nobs <- nrow(X)    # needed by the initialize expression below
  p <- nvars <- ncol(X)   # needed by the initialize expression below
  
  eval(init) # initializes n and m (total nr of trials for binomial) and fitted values mustart based on y (mu=expected value on response scale)
  
  if (is.null(start)) {  
    eta = as.matrix(link(mustart))
    # to initialise using an orthogonal initialisation
    # beta <-  beta_old <- start <- init_coefs(X = X, weights = weights, offset = offset, mu = mu, family = family, lambda = lambda)
    # eta = as.matrix(offset + as.vector(if (p == 1L) X * start else X %*% start)) # eta = expected value on link scale
    # to initialise with constant starting values
    beta <-  beta_old <- start <- start_coefs(X=X, family=family) # initial model coefficients - e.g. sqrt(3) correspond in a Bayesian sense to SD on Gaussian prior of 3, which is most common prior in Bayesian stats (lambda=1/start^2 and lambda=1/SD prior)
  } else {  
    # eta = as.matrix(link(mustart))
    beta <- beta_old <- start # when starting coefficient values were provided
    # WE ASSUME THAT IF STARTING VALUES ARE GIVEN THEY ARE ALREADY QUITE GOOD AND SO USE
    eta = as.matrix(offset + as.vector(if (p == 1L) X * start else X %*% start)) # eta = expected value on link scale
  }
  names(beta) = colnames(X)
  mu = linkinv(eta) # expected value on response scale
  dev = sum(dev.resids(y, mu, weights)) # deviance 
  residuals = rep(0, nobs)
  
  if (is.null(start)) { nonzero = as.vector(beta!=0) } else { nonzero = as.vector(start!=0) } # nonzero coefficients
  # mask <- rep(FALSE, p)
  
  for (i in 1L:maxit) {
    varg = variance(mu) # variance
    
      if (family$link == "identity"){ # simplified formula and faster than formula in else statement
        W.ret <- as.vector(weights / varg) # updated 1/variance (* weights) weights with identity link, where variance = 1 with Gaussian noise, variance = mu, mu^2 and mu^3 with Poisson, Gamma & inverse Gaussian noise
        good = which(!is.na(W.ret) & (W.ret!=0) & !is.infinite(W.ret)) # valid rows # (gprime != 0)
        z.ret <- (y - offset) # working (adjusted) response (returned non-subsetted version)
        z <- z.ret[good] # subset used for fit
        W <- W.ret[good] # subset of weights used for fit
      } else {
        gprime = mu.eta(eta) # derivative of the expected values
        good = which((weights != 0) & (gprime != 0) & !is.infinite(weights) & !is.na(weights)) # valid rows
        z.ret <- (eta - offset) + (y - mu) / gprime # working (adjusted) response
        z <- z.ret[good] 
        W.ret <- weights * as.vector(gprime^2 / varg) # updated weights 
        W <- W.ret[good] # subset of weights used for fit
      }
    
    if(!is.null(prior.mean)){ 
      center = prior.mean # nonzero centered ridge regression
    } else {
      center = NULL # zero centered ridge regression
    }
    
    # update ridge penalties
    pen.weights <- AR.weights(beta = beta, gamma = gamma) # adaptive ridge pentalty weights
    lambdas = (1/4)*lambda*dispersion*pen.weights # ridge penalties on individual coefficients, we scale these penalties by the estimated dispersion & by 1/4 (cf Frommlet & Nuel) so that we can directly use the lambda penalty values implied by the AIC & BIC criteria (e.g. 2 for AIC)
    lambdas[no.pen] = 0 # unpenalized terms (e.g. intercept)
    
    if (length(good)==0) {
      conv <- FALSE
      if(verbose) print(gettextf("No observations informative at iteration %d",
                                 i), domain = NA)
      break
    }
    
    beta_old = beta

    # weighted least square step in IRLS algo, here replaced by ridge regression to
    # add automatic regularisation and with possible box constraints
    res <- lmridge(X = X[good, nonzero, drop=F], 
                   y = z,
                   weights = W, # fixed bug: had W[good] but already subsetted
                   lambdas = lambdas[nonzero],
                   nonnegative = nonnegative,
                   scaling = scaling[nonzero],
                   start = start[nonzero], # as.vector(crossprod(Xwaug, ywaug) / colSums(Xwaug^2)),
                   lower = lower[nonzero], 
                   upper = upper[nonzero],
                   prior.mean = center[nonzero],
                   solver = solver,
                   control.solver = control.solver,
                   method = method)
    if (sum(res) != 0) {
      beta[nonzero] <- res
    } 

    beta[nonzero][abs(beta[nonzero]) < thresh] = 0
    nonzero = as.vector(beta!=0) # nonzero coefficients
    if(sum(nonzero) == 0){
      conv <- TRUE
      if(verbose) warning("All coefficients penalized to zero")
      break
    }
    if (any(!is.finite(beta))) {
      conv <- FALSE
      if(verbose) warning(gettextf("Non-finite coefficients at iteration %d", i), domain = NA)
      break
    }
    
    ## calculate updated values of eta and mu with the new coefs:
    eta = as.matrix(X[,nonzero,drop=F] %*% beta[nonzero] + offset) # expected value / predictions on link scale
    mu = linkinv(eta) # expected value / predictions on response scale

    # update estimated dispersion for all distributions except binomial & poisson
    # and if relative change in estimated dispersion drops below threshold
    # update dispersion to use it in calculated ridge penalty
    # we only do this update once
    # if a dispersion different than 1 is passed to L0glm.fit we keep it at that value
    if (is.null(dispersion_init)) {
      
      residuals_old = residuals
      
      if (family$link == "identity"){ # simplified formula and faster than formula in else statement
        residuals <- y-mu # residuals
      } else {
        residuals <- (y-mu)/gprime # residuals
      }
      
      n.ok <- length(good) # good observations
      rank <- sum(nonzero) # estimated rank
      df.residual <- n.ok
      if (rank<n.ok) { df.residual <- df.residual - rank } # to also allow for high dimensional case
      # print(df.residual)
      dispersion_old <- sum((W.ret[good] * residuals_old[good]^2))/df.residual # previous iteration's estimated dispersion # TODO sometimes causes Error longer object length is not a multiple of shorter object length
      dispersion_new <- sum((W.ret[good] * residuals[good]^2))/df.residual # updated estimate of dispersion (variance for Gaussian case)
      disp_rel_change <- abs(dispersion_new - dispersion_old) / dispersion_old
      # print(i)
      # print(disp_rel_change)
      # start updating dispersion used in calculation of lambda when estimated dispersion 
      # converged (relative change in dispersion between iterations < 10%)
      if (disp_rel_change < 0.1) {
        dispersion <- dispersion_new 
        dispersion_init <- 1 # to stop updating dispersion in subsequent iterations
      }
      # print(dispersion)
    }
      
    dev_old = dev
    dev = sum(dev.resids(y, mu, weights)) # deviance
    
    dev_rel_change = sqrt(sum((beta - beta_old)^2)) / sqrt(sum(beta^2)) # relative change in L2 norm of coefficient vector
    if (dev_rel_change < tol) break
    dev_old = dev
    beta_old = beta 
  }

  # browser()
  
  return(list(coefficients = as.vector(beta), 
              weights = as.vector(W.ret), # working weights
              # residuals = as.vector(residuals.ret), # working residuals
              dispersion = dispersion, # estimated dispersion
              # pen.weights = as.vector(pen.weights), 
              lambdas = as.vector(lambdas), z = as.vector(z.ret)))
}

