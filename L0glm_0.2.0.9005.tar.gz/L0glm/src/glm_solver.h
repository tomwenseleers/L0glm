#ifndef L0GLM_GLM_SOLVER_H
#define L0GLM_GLM_SOLVER_H

// This header is included inside L0glmNative, after the working-design helpers.
struct SolverControl {
  int method=0, maxit=0;
  unsigned int pivot=0, ordering=0, precond=0, svd=0, sparse_svd=1;
  double tol=0, threshold=0,workspace=std::numeric_limits<double>::infinity();
  bool rowaug=false,polish=false,cache_selected=true;
  SEXP bridge=R_NilValue;
  SolverControl()=default;
  template<class T> T option(List x,const char* name,T fallback) {
    return x.containsElementNamed(name)&&!Rf_isNull(x[name])?as<T>(x[name]):fallback;
  }
  SolverControl(List x,SEXP callback,int threads=1):bridge(callback) {
    double total=option<double>(x,".workspace.total",-1);
    if(total<0){double gb=option<double>(x,"max.memory",-1);total=gb<0?-1:gb*1073741824.;}
    workspace=L0glm::workspace_budget(total,callback==R_NilValue?threads:1);
    std::string type=option<std::string>(x,"method","chol");
    method=type=="CG"?1:type=="LSCG"?2:type=="QR"?3:type=="SVD"?4:0;
    pivot=option<unsigned int>(x,"pivot",0);ordering=option<unsigned int>(x,"ordering",0);
    precond=option<unsigned int>(x,"precond",0);svd=option<unsigned int>(x,"svd",0);
    sparse_svd=option<unsigned int>(x,"sparse.svd",1);maxit=option<int>(x,"maxit",0);
    tol=option<double>(x,"tol",0);threshold=option<double>(x,"threshold",0);
    cache_selected=option<bool>(x,".cache.selected",true);
    rowaug=option<bool>(x,"rowaug",false);polish=option<std::string>(x,"nonnegative.method","clamp")=="constrained";
  }
  bool external() const {return bridge!=R_NilValue;}
};
template<class Matrix> L0glm::SolverResult eigen_solve(const Matrix& A,const MatrixXd& b,
  const MatrixXd& start,const SolverControl& control) {
  using Ref=std::conditional_t<std::is_same_v<Matrix,MatrixXd>,L0glm::DenseRef,L0glm::SparseRef>;
  Ref design(A);L0glm::DenseRef rhs(b),guess(start);
  switch(control.method) {
    case 0:return L0glm::chol_solve(design,rhs,control.pivot,control.ordering);
    case 1:return L0glm::cg_solve(design,rhs,guess,control.tol,control.maxit,control.precond);
    case 2:return L0glm::lscg_solve(design,rhs,guess,control.tol,control.maxit,control.precond);
    case 3:return L0glm::qr_solve(design,rhs,control.pivot,control.ordering);
    case 4:return L0glm::svd_solve(design,rhs,std::is_same_v<Matrix,MatrixXd>?control.svd:control.sparse_svd,
      control.precond,control.threshold);
  }
  return L0glm::SolverResult();
}
template<class Matrix> bool eigen_coefficients(const Matrix& A,const MatrixXd& b,
  const MatrixXd& start,const SolverControl& control,State& state,MatrixXd& answer,
  bool least_squares=false) {
  // For an already formed SPD system, solve G beta = h directly with CG-IC.
  // Applying LSCG here would instead work with G' G and worsen conditioning.
  SolverControl kernel=control;
  if(control.method==2&&!least_squares)kernel.method=1;
  if(least_squares&&kernel.method==2&&kernel.precond==2&&
      L0glm::gram_workspace(A)>control.workspace)kernel.precond=1;
  if(kernel.method==0||kernel.method>=3)L0glm::require_workspace(
    least_squares?L0glm::matrix_workspace(A):L0glm::matrix_workspace(A),control.workspace,"Eigen factorization");
  auto result=eigen_solve(A,b,start,kernel);
  if(result.finite() && (result.success || control.method!=2)) {
    if(!result.success && (control.method==1||control.method==2))++state.solver_inexact;
    answer=result.coefficients;return true;
  }
  if(control.method!=0) {
    L0glm::require_workspace(least_squares?L0glm::gram_workspace(A):L0glm::matrix_workspace(A),
      control.workspace,"LLT fallback");
    ++state.solver_fallbacks;SolverControl fallback=control;fallback.method=0;fallback.pivot=0;
    if(least_squares) {
      Matrix gram=sym_gram(A);
      MatrixXd rhs=right_product(A,b);
      result=eigen_solve(gram,rhs,start,fallback);
    }else result=eigen_solve(A,b,start,fallback);
    if(result.finite()){answer=result.coefficients;return true;}
  }
  return false;
}
inline SparseMatrix<double> sparse_copy(const MatrixXd& A) {return A.sparseView();}
inline SparseMatrix<double> sparse_copy(const SparseMatrix<double>& A) {return A;}
template<class Matrix> SparseMatrix<double> augmented_design(const Matrix& A,const VectorXd& d) {
  SparseMatrix<double> sparse=sparse_copy(A);
  std::vector<Eigen::Triplet<double>> entries;entries.reserve(sparse.nonZeros()+d.size());
  for(int j=0;j<sparse.cols();++j)for(SparseMatrix<double>::InnerIterator it(sparse,j);it;++it)
    entries.emplace_back(it.row(),j,it.value());
  for(int j=0;j<d.size();++j)if(d[j]!=0)entries.emplace_back(A.rows()+j,j,std::sqrt(d[j]));
  SparseMatrix<double> result(A.rows()+d.size(),A.cols());
  result.setFromTriplets(entries.begin(),entries.end());return result;
}
template<class Matrix> bool selected_dual(const Matrix& A,const VectorXd& response,
  const VectorXd& penalty,VectorXd center,const SolverControl& control,State& state,VectorXd& fit) {
  const int n=A.rows(),p=A.cols();bool penalized=(penalty.array()>0).any();
  std::vector<int> free;VectorXd inv=VectorXd::Ones(p);
  for(int j=0;j<p;++j)if(penalized) {
    inv[j]=penalty[j]>0?1/std::sqrt(penalty[j]):0;
    if(penalty[j]==0){free.push_back(j);center[j]=0;}
  }else center[j]=0;
  Matrix Z=A*inv.asDiagonal();L0glm::drop_exact_zeros(Z);
  if(L0glm::gram_workspace(Z,true)>control.workspace) {
    if(control.method!=1&&control.method!=2)
      L0glm::require_workspace(L0glm::gram_workspace(Z,true),control.workspace,"Woodbury factorization");
    auto value=L0glm::matrixfree_dual(A,response,penalty,center,control.tol,control.maxit);
    if(!value.success)return false;
    fit=value.coefficients.col(0);return true;
  }
  Matrix G=row_gram_native(Z);
  if(penalized)add_diagonal(G,VectorXd::Ones(n));
  MatrixXd rhs(n,free.size()+1),solution,U(n,free.size());rhs.col(0)=response-A*center;
  for(int j=0;j<(int)free.size();++j){U.col(j)=A.col(free[j]);rhs.col(j+1)=U.col(j);}
  if(!eigen_coefficients(G,rhs,MatrixXd::Zero(n,rhs.cols()),control,state,solution))return false;
  VectorXd u=solution.col(0),alpha(free.size());
  if(!free.empty()) {
    MatrixXd T=solution.rightCols(free.size()),K=U.transpose()*T;
    alpha=qr_solve(K,U.transpose()*u);u.noalias()-=T*alpha;
  }
  fit=center+inv.asDiagonal()*(Z.transpose()*u);
  for(int j=0;j<(int)free.size();++j)fit[free[j]]=alpha[j];
  return fit.allFinite();
}
template<class Matrix> bool primal_ridge(const Matrix& A,const VectorXd& response,
  const VectorXd& penalty,const VectorXd& center,const VectorXd& start,
  const SolverControl& control,State& state,VectorXd& fit,
  const VectorXd& lower,const VectorXd& upper,bool polish_eligible,L0glm::RidgeWorkspace<Matrix>* workspace=nullptr) {
  double estimate=workspace?workspace->estimate():L0glm::gram_workspace(A);
  if(estimate>control.workspace) {
    if(control.method!=1&&control.method!=2)L0glm::require_workspace(estimate,control.workspace,"Eigen Gram solve");
    auto value=L0glm::matrixfree_ridge(A,response,penalty,center,start,control.tol,control.maxit);
    if(!value.success)return false;
    fit=value.coefficients.col(0);return true;
  }
  Matrix G=workspace?workspace->gram():sym_gram(A);add_diagonal(G,penalty);
  MatrixXd rhs=workspace?MatrixXd(workspace->rhs()):right_product(A,MatrixXd(response));rhs.col(0)+=penalty.cwiseProduct(center);
  MatrixXd solution;
  if(!eigen_coefficients(G,rhs,MatrixXd(start),control,state,solution))return false;
  fit=solution.col(0);
  if(control.polish&&polish_eligible)fit=L0glm::nonnegative_polish(G,VectorXd(rhs.col(0)),fit,lower,upper);
  return true;
}
template<class Design> VectorXd ridge_selected(const Design& X,State& state,
  const std::vector<int>& active,const SolverControl& control,int iteration,
    L0glm::RidgeWorkspace<std::conditional_t<std::is_same_v<Design,Eigen::Map<MatrixXd>>,MatrixXd,SparseMatrix<double>>>* workspace=nullptr) {
  using Matrix=std::conditional_t<std::is_same_v<Design,Eigen::Map<MatrixXd>>,MatrixXd,SparseMatrix<double>>;
  L0glm::RidgeWorkspace<Matrix> temporary;auto& work=workspace?*workspace:temporary;
  auto rows=positive_rows(state.W);const int n=rows.size(),p=active.size();
  VectorXd response(n),inv(p),d(p),center(p),guess(p),lower(p),upper(p);
  bool scaled=(state.scale.array()!=1).any();
  for(int i=0;i<n;++i)response[i]=state.z[rows[i]]*std::sqrt(state.W[rows[i]]);
  for(int j=0;j<p;++j) {
    const int a=active[j];inv[j]=1/state.scale[a];d[j]=state.lambdas[a]/(state.scale[a]*state.scale[a]);
    center[j]=state.prior[a]*state.scale[a];guess[j]=state.beta[a]*state.scale[a];
    lower[j]=scaled&&state.lower[a]<=-DBL_MAX?R_NegInf:state.lower[a]*state.scale[a];
    upper[j]=scaled&&state.upper[a]>=DBL_MAX?R_PosInf:state.upper[a]*state.scale[a];
  }
  VectorXd selected_scale(p);for(int j=0;j<p;++j)selected_scale[j]=state.scale[active[j]];
  work.update(X,rows,active,state.W,selected_scale,state.z,true);
  const auto& A=work.A;VectorXd fit(p);bool success=false;
  if(control.external()) {
    // Dependency wrappers allocate R objects; callers execute this branch on
    // the R thread, never in OpenMP workers.
    Function solve(control.bridge);
    // Keep every wrapped argument alive while the remaining arguments allocate.
    // A large design wrap can trigger GC before the callback's call is built.
    Shield<SEXP> rA(wrap(A)), rResponse(wrap(response)), rD(wrap(d));
    Shield<SEXP> rCenter(wrap(center)), rGuess(wrap(guess));
    Shield<SEXP> rLower(wrap(lower)), rUpper(wrap(upper));
    Shield<SEXP> answer(solve(SEXP(rA),SEXP(rResponse),SEXP(rD),SEXP(rCenter),
      SEXP(rGuess),SEXP(rLower),SEXP(rUpper),iteration));
    fit=as<VectorXd>(SEXP(answer));success=fit.size()==p&&fit.allFinite();
  }else if(p>n && (d.array()>=0).all() && ((d.array()==0).all() || (d.array()==0).count()<=n)) {
    success=selected_dual(A,response,d,center,control,state,fit);
  }else if(control.rowaug && control.method>=2 && (d.array()!=0).any()) {
    SparseMatrix<double> augmented=augmented_design(A,d);VectorXd rhs(n+p);rhs.head(n)=response;
    if((center.array()==0).all())rhs.tail(p).setZero();else rhs.tail(p)=d.cwiseSqrt().cwiseProduct(center);
    if(control.method>=2) {
      MatrixXd solution;success=eigen_coefficients(augmented,MatrixXd(rhs),MatrixXd(guess),control,state,solution,true);
      if(success)fit=solution.col(0);
    }else success=primal_ridge(augmented,rhs,VectorXd::Zero(p),VectorXd::Zero(p),guess,control,state,fit,lower,upper,p<=n);
  }else if(control.rowaug && control.method>=2) {
    MatrixXd solution;success=eigen_coefficients(A,MatrixXd(response),MatrixXd(guess),control,state,solution,true);
    if(success)fit=solution.col(0);
  }else success=primal_ridge(A,response,d,center,guess,control,state,fit,lower,upper,p<=n,&work);
  // A rectangular LSCG solve is unconstrained. Certify its bound correction
  // against the same predictor-space quadratic, including ridge centers.
  // This is explicit opt-in work and remains subject to the Gram budget.
  if(success&&control.polish&&control.method==2&&L0glm::nonnegative_polish_needed(fit,lower,upper)) {
    L0glm::require_workspace(work.estimate(),control.workspace,"constrained LSCG polish");
    Matrix G=work.gram();add_diagonal(G,d);
    VectorXd h=work.rhs()+d.cwiseProduct(center);
    fit=L0glm::nonnegative_polish(G,h,fit,lower,upper);
  }
  VectorXd result=state.beta;
  if(!success){state.solver_failed=true;return result;}
  for(int j=0;j<p;++j)result[active[j]]=fit[j]/state.scale[active[j]];
  return result;
}
#endif
