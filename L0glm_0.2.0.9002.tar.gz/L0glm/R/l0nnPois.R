#' Fast nonnegative identity-link Poisson L0 or grouped L0 penalized fit
#'
#' `l0nnPois()` is a fast RcppEigen/OpenMP implementation of
#' [l0glmFit()] for the nonnegative Poisson model with identity link. It shares
#' the main fitting arguments with `l0glmFit()` for use in deconvolution
#' workflows, and internally uses the sparse or dense Eigen Cholesky LLT ridge solver.
#' `l0glmFit(openmp = TRUE)` selects this backend automatically for eligible
#' fits. Its specialized Poisson updates and the general native Eigen driver
#' keep the design matrix `X` in shared memory across outcome channels.
#' Dense inputs retain dense storage and sparse inputs retain sparse storage.
#' The dense solver forms weighted crossproducts using R's BLAS library.
#' Eligible wide active systems use the Woodbury identity to factor an
#' observation-space system rather than a predictor-space system.
#' The default penalty is `lambda = "gic"`. Optional `precluster=TRUE`
#' screens summed channel groups and refines on the original responses; see
#' [preclustering] for aggregate-only output and clustering controls.
#' Smooth IRLS updates use the same fixed-penalty backtracking safeguard as
#' `l0glmFit()`, followed by the selection cutoff. Trial steps reuse predictor
#' differences and require no additional ridge solve.
#' Every coefficient, including any intercept, is constrained to be nonnegative.
#' The LLT sparse-selection update clamps negative proposals to zero.
#' Unpenalized intercepts and `always.include` terms are refined using a small
#' constrained Poisson solve; see [compulsory_terms].
#' With positive active effects and well-chosen regularization such as
#' `lambda="gic"`, ridge shrinkage often keeps genuine active effects positive.
#' See the solver discussion in [l0glmFit()] for measured comparisons with
#' the formally constrained alternatives.
#' This constraint cannot be disabled. Use `l0glmFit(nonnegative = FALSE)`
#' if coefficients of either sign are required.
#'
#' @inheritParams l0glmFit
#' @param family The identity-link Poisson family, \code{poisson("identity")}.
#' @param validation Optional held-out data and stopping controls as in
#'   \code{l0glmFit()}. Held-out deviance is scored directly in C++,
#'   retaining OpenMP threading across channels and restoring the best selection
#'   or relaxed-refit checkpoint. Validation predictors are shared across threads.
#' @param dispersion Poisson dispersion is fixed at 1. Accepts \code{NULL}
#'   or 1; other finite nonzero numeric values are ignored with a warning.
#'   Negative values cannot request dispersion estimation for this family.
#' @param intercept Logical; if \code{TRUE}, add an intercept column to \code{X}.
#'   The intercept is constrained to be nonnegative, just like every other
#'   coefficient. Defaults to \code{FALSE}.
#' @param ncores Optional integer specifying the number of OpenMP threads to use
#'   across outcome channels when \code{parallelize=TRUE}. For \code{l0nnPois},
#'   the requested value is capped only at the detected number of logical cores,
#'   not at the number of physical cores.
#' @param control.solver Optional list of solver controls. \code{l0nnPois}
#'   always uses Eigen Cholesky LLT internally, but for sparse matrices
#'   \code{control.solver$NaturalOrdering} can be set to \code{TRUE} or
#'   \code{FALSE} to choose Eigen \code{NaturalOrdering} or
#'   \code{AMDOrdering}. The default is \code{FALSE}. Integer
#'   \code{control.solver$ordering} uses \code{1L} for
#'   natural ordering and \code{0L} meaning AMD ordering.
#'
#' @return An object of class \code{L0glm_fit}, with the same main components as [l0glmFit()]:
#'   `coefficients`, `weights`, `dispersion`, `init.lambda`, `lambdas`,
#'   `family`, `z`, `X`, and `y`. Original prior weights and offsets are
#'   retained separately from the working weights for scoring. Methods
#'   \code{coef()}, \code{logLik()}, \code{AIC()}, \code{BIC()}, \code{GIC()},
#'   \code{EBIC()} and \code{MBIC()} are available; see \link{model_criteria}.
#'   \code{print()} and \code{summary()} provide compact model displays;
#'   see \link{model_summary}.
#'   \code{predict()} and \code{fitted()} return original-scale Poisson means;
#'   see \link{model_predictions} for new data and prediction offsets.
#'
#' @seealso \link{l0glmFit}, \link{information_criteria} for case-insensitive
#'   criterion presets, penalty formulas, guidance and original references.
#'   See \href{https://tomwenseleers.github.io/L0glm/articles/performance.html}{the benchmark article}
#'   for measured deconvolution and validation timings.
#'
#' @example examples/l0nnPois.R
#'
#' @export
l0nnPois <- function(X,
                     y,
                     weights       = NULL,
                     family        = poisson(identity),
                     dispersion    = NULL,
                     start         = NULL,
                     offset        = NULL,
                     lambda        = "gic",
                     intercept     = FALSE,
                     always.include        = NULL,
                     normalize     = "auto",
                     solver        = "eigen",
                     method        = 1L,
                     parallelize   = TRUE,
                     ncores        = L0glm_default_ncores(parallelize),
                     nthreads      = NULL,
                     maxit         = 25,
                     grouped       = TRUE,
                     group.maxit   = 6,
                     relaxed       = grouped & NCOL(y) > 1,
                     prior.mean    = NULL,
                     thresh         = 1e-5,
                     tol           = 1e-10,
                     control.solver = do.call("controlSolverGen", list(solver = solver, method = method)),
                     verbose       = FALSE,
                     validation    = NULL,
                     precluster    = FALSE,
                     cluster.refit = TRUE,
                     control.precluster = list(),
                     local.search = "auto",
                     control.local = list(), group = NULL, group.multiplier = NULL,
                     interactions = 0L, control.interactions = list()) {
  interactions <- L0glm_interaction_order(interactions)
  if(inherits(X,'L0glm_data'))X <- L0glm_data_matrix(X)
  if(interactions>0L) {
    if(!inherits(family,'family'))family <- family()
    if(family$family!='poisson' || family$link!='identity')
      stop('l0nnPois is only defined for family = poisson(identity).',call.=FALSE)
    supplied <- names(match.call())[-1L]
    args <- mget(supplied,environment(),inherits=FALSE)
    args$family <- family;args$nonnegative <- TRUE;args$screen <- 'none'
    if(missing(lambda))args$lambda <- 'gic'
    return(L0glm_interaction_fit(args,interactions,control.interactions))
  }
  if (!is.null(group)) {
    if(!inherits(family,'family'))family <- family()
    if(family$family!='poisson' || family$link!='identity')
      stop('l0nnPois is only defined for family = poisson(identity).',call.=FALSE)
    args <- mget(names(formals(l0nnPois)),environment(),inherits=FALSE)
    return(do.call(l0glmFit,c(args,list(nonnegative=TRUE,screen='none'))))
  }
  if (!identical(local.search, FALSE)) {
    mode <- L0glm_local_mode(local.search)
    supplied <- setdiff(names(match.call())[-1L], c("local.search", "control.local"))
    if (isFALSE(parallelize) || NCOL(y)==1L) supplied <- setdiff(supplied,"ncores")
    arguments <- mget(supplied, envir=environment(), inherits=FALSE)
    return(L0glm_local_fit(l0nnPois, arguments, mode, control.local, nonnegative=TRUE))
  }
  L0glm_precluster_flags(precluster,cluster.refit)
  if (!solver %in% c("eigen", "bigGlm", "bigglm", "glmnet", "osqp"))
    stop("Invalid solver choice; use eigen, bigGlm, or osqp.", call. = FALSE)
  nuisance <- isTRUE(maxit>1L) && !isFALSE(control.solver$.nuisance)
  if(nuisance) {
    if(is.data.frame(X)) X <- as.matrix(X)
    if(!inherits(family,"family")) family <- family()
    nuisance <- isTRUE(intercept) || length(always.include)>0L || length(L0glm_intercepts(X))>0L
    if(!nuisance) control.solver$.nuisance <- FALSE
  }
  if (nuisance && (!precluster || cluster.refit)) {
    if(!inherits(family,"family")) family <- family()
    if(!identical(L0glm_ext_kind(family),"multinomial") &&
       !(family$family %in% c("binomial","quasibinomial") && !length(always.include))) {
      supplied <- names(match.call())[-1L]
      if(!is.null(validation) && !inherits(validation,"L0glm_validation")) {
        args <- mget(supplied,envir=environment(),inherits=FALSE)
        args$family <- family
        args$nonnegative <- TRUE; args$openmp <- TRUE; args$screen <- "none"
        return(L0glm_validated_fit(args))
      }
      options <- mget(setdiff(names(formals(l0nnPois)),c("X","y")),envir=environment(),inherits=FALSE)
      options$nonnegative <- TRUE
      return(L0glm_nuisance_fit(X,y,options,l0nnPois,supplied))
    }
  }
  if(precluster) {
    if(!inherits(family,"family")) family<-family()
    options<-mget(setdiff(names(formals(l0nnPois)),c("X","y")),envir=environment(),inherits=FALSE)
    options$nonnegative<-TRUE
    return(L0glm_precluster_fit(X,y,options,l0nnPois,names(match.call())[-1L]))
  }
  validate_thresh(thresh)
  normalization <- L0glm_normalization(normalize, nonnegative = TRUE)
  normalization_code <- match(normalization, c("none", "l2", "rms", "sd")) - 1L
  if (!inherits(family, "family")) family <- family()
  if (!identical(family$family, "poisson") || !identical(family$link, "identity")) {
    stop("l0nnPois is only defined for family = poisson(identity).",
         call. = FALSE)
  }
  if (!identical(solver, "eigen") || as.integer(method[1L]) != 1L) {
    warning("l0nnPois always uses the Eigen Cholesky LLT solver; ",
            "solver and method were ignored.", call. = FALSE)
  }
  dispersion <- L0glm_dispersion(dispersion, family, NCOL(y))
  if (!is.null(validation) && !inherits(validation, "L0glm_validation")) {
    args <- mget(names(match.call())[-1L], envir = environment(), inherits = FALSE)
    args$family <- family; args$lambda <- lambda; args$intercept <- intercept
    args$nonnegative <- TRUE; args$openmp <- TRUE
    args$solver <- "eigen"; args$method <- 1L
    # Direct calls keep this specialized backend; l0glmFit owns screening.
    args$screen <- "none"
    args$control.solver <- control.solver[intersect(names(control.solver),
      c("NaturalOrdering", "ordering"))]
    return(do.call(l0glmFit, args))
  }
  if (!is.null(nthreads) && verbose) {
    message("l0nnPois uses ncores for OpenMP outcome-interactions threading; nthreads is ignored.")
  }
  natural_ordering <- FALSE
  if (!is.null(control.solver)) {
    if (!is.null(control.solver$NaturalOrdering)) {
      natural_ordering <- isTRUE(control.solver$NaturalOrdering)
    } else if (!is.null(control.solver$ordering)) {
      natural_ordering <- as.integer(control.solver$ordering[1L]) == 1L
    }
  }

  y <- as.matrix(y)
  storage.mode(y) <- "double"
  if (any(!is.finite(y)) || any(y < 0)) {
    stop("Poisson responses must be finite and nonnegative.", call. = FALSE)
  }
  n <- nrow(X)
  p0 <- ncol(X)
  m <- ncol(y)
  if (!identical(nrow(y), n)) {
    stop("nrow(y) must equal nrow(X).", call. = FALSE)
  }

  issparse <- inherits(X, "sparseMatrix")
  if (issparse) {
    X <- methods::as(Matrix::Matrix(X, sparse = TRUE), "dgCMatrix")
  } else {
    X <- as.matrix(X)
    storage.mode(X) <- "double"
  }

  if (intercept) {
    predictor_names <- colnames(X)
    X <- if (issparse) {
      methods::as(cbind(Intercept = Matrix::Matrix(1, n, 1, sparse = TRUE), X),
                  "dgCMatrix")
    } else {
      cbind(Intercept = 1, X)
    }
    colnames(X) <- c("Intercept", if (is.null(predictor_names)) rep("", p0) else predictor_names)
    always.include <- c(1L, always.include + 1L)
  }
  p <- ncol(X)
  always.include <- L0glm_mandatory(X, always.include)
  p_selectable <- L0glm_criterion_size(p-length(always.include),control.solver)
  preprocessing <- L0glm_preprocessing(X, normalize, rep(0, p), always.include)
  lambda <- L0glm_resolve_lambda(lambda, p = max(1L, p_selectable), n = n)
  init.lambda <- lambda
  start <- L0glm_unit_start(start, X, preprocessing, m)

  weights <- L0glm_observation_input(weights,n,m,1,"weights")
  offset <- L0glm_observation_input(offset,n,m,0,"offset")
  weights <- as.matrix(weights);storage.mode(weights)<-"double"
  offset <- as.matrix(offset);storage.mode(offset)<-"double"

  if (!is.null(start)) {
    if (length(start) == 1L) {
      start <- matrix(as.numeric(start), p, m)
    } else {
      start <- as.matrix(start)
      if (intercept && nrow(start) == p0) {
        start <- rbind(0, start)
      }
      if (m > 1L && ncol(start) == 1L) {
        start <- matrix(rep(start, m), nrow = nrow(start), ncol = m)
      }
    }
    storage.mode(start) <- "double"
    if (!identical(dim(start), c(p, m))) {
      stop("start must be a scalar, have dimension p x m, or have length p for univariate y.",
           call. = FALSE)
    }
    if (any(!is.finite(start)))
      stop("start must contain finite coefficients.", call. = FALSE)
  }

  if (is.null(prior.mean)) {
    prior.mean <- matrix(0, p, m)
  } else {
    prior.mean <- as.matrix(prior.mean)
    storage.mode(prior.mean) <- "double"
    if (intercept && nrow(prior.mean) == p0) {
      prior.mean <- rbind(0, prior.mean)
    }
    if (m == 1L) {
      if (length(prior.mean) != p) {
        stop("prior.mean must have length p for univariate y.", call. = FALSE)
      }
      prior.mean <- matrix(prior.mean, p, 1L)
    } else if (ncol(prior.mean) == 1L) {
      prior.mean <- matrix(rep(prior.mean, m), p, m)
    } else if (!identical(dim(prior.mean), c(p, m))) {
      stop("prior.mean must be p x m when y has m columns.", call. = FALSE)
    }
  }

  always.include <- as.integer(always.include)
  always.include <- always.include[!is.na(always.include) &
                                     always.include >= 1L &
                                     always.include <= p]
  if (isTRUE(parallelize) && m > 1L) {
    ncores <- suppressWarnings(as.integer(ncores[1L]))
    if (is.na(ncores) || ncores < 1L) ncores <- 1L
    logical_cores <- suppressWarnings(parallel::detectCores(logical = TRUE))
    if (!is.na(logical_cores) && logical_cores >= 1L &&
        ncores > logical_cores) {
      warning("ncores capped at logical core count = ", logical_cores,
              call. = FALSE)
      ncores <- as.integer(logical_cores)
    }
  } else {
    ncores <- 1L
  }
  if (is.null(start) && maxit > 1L && any(offset != 0))
    start <- L0glm_signal_start(X,y,offset,weights,always.include,prior.mean,ncores)
  allowed <- if (is.null(start)) NULL else start != 0
  if (!is.null(allowed)) allowed[always.include, ] <- TRUE

  if (!is.null(validation)) {
    validation$X <- if (inherits(validation$X, "sparseMatrix"))
      methods::as(validation$X, "dgCMatrix") else as.matrix(validation$X)
  }
  if (issparse) {
    fit <- L0nnpois_sparse_cpp(
      X, y, weights, offset, prior.mean, start, always.include,
      lambda, normalization_code, preprocessing$scale, grouped, relaxed, as.integer(group.maxit),
      as.integer(maxit), thresh, tol, ncores,
      natural_ordering, validation)
  } else {
    fit <- L0nnpois_dense_cpp(
      X, y, weights, offset, prior.mean, start, always.include,
      lambda, normalization_code, preprocessing$scale, grouped, relaxed, as.integer(group.maxit),
      as.integer(maxit), thresh, tol, ncores,
      natural_ordering, validation)
  }

  coefficients <- fit$coefficients
  weights.ret <- fit$weights
  lambdas <- fit$lambdas
  z <- fit$z
  dispersion <- fit$dispersion
  if (!is.null(allowed)) lambdas[!allowed] <- Inf

  weights.ret[is.infinite(weights.ret)] <- 1e11
  lambdas[is.infinite(lambdas)] <- 1e11

  if (m == 1L) {
    coefficients <- Matrix::Matrix(coefficients[, 1L], ncol = 1L,
                                   sparse = TRUE,
                                   dimnames = list(colnames(X), NULL))
    weights.ret <- as.numeric(weights.ret[, 1L])
    lambdas <- as.numeric(lambdas[, 1L])
    z <- as.numeric(z[, 1L])
    dispersion <- as.numeric(dispersion[1L])
  } else {
    coefficients <- Matrix::Matrix(coefficients, sparse = TRUE,
                                   dimnames = list(colnames(X), colnames(y)))
    weights.ret <- Matrix::Matrix(weights.ret, sparse = TRUE)
    lambdas <- Matrix::Matrix(lambdas, sparse = TRUE)
    z <- Matrix::Matrix(z, sparse = TRUE)
    dispersion <- as.numeric(dispersion)
  }
  coefficients <- methods::as(methods::as(coefficients, "generalMatrix"), "CsparseMatrix")

  result <- structure(list(coefficients = coefficients,
       weights      = weights.ret,
       prior.weights = weights,
       offset       = offset,
       dispersion   = dispersion,
       dispersion.estimated = rep(FALSE, m),
       init.lambda  = init.lambda,
       lambdas      = lambdas,
       family       = family,
       p            = p_selectable,
       always.include = always.include,
       preprocessing = preprocessing,
       convergence = fit$convergence,
       added_intercept = intercept,
       grouped      = grouped,
       z            = z,
       X            = if (issparse) X else Matrix::Matrix(X, sparse = FALSE),
       y            = y), class = "L0glm_fit")
  if (!is.null(validation)) {
    result$validation <- fit$validation
    result$validation$deviance <- L0glm_validation_loss(validation, coefficients)
  }
  result
}

L0glm_nnpois_kernel <- l0nnPois
l0nnPois <- L0glm_recorded_fitter(L0glm_nnpois_kernel,'l0nnPois')
