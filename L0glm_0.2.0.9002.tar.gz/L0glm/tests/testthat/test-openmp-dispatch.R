# These component checks isolate IRLS/tuning from final support refinement.
test_that("eligible l0glmFit calls forward all fitting controls to l0nnPois", {
  local_mocked_bindings(l0nnPois = function(...) list(args = list(...)))
  X <- matrix(1, 5, 3)
  y <- cbind(1:5, 2:6)
  args <- list(
    local.search = FALSE,
    X = X, y = y, family = poisson(identity), nonnegative = TRUE,
    weights = rep(2, 5), dispersion = 1, start = matrix(1, 3, 2),
    offset = rep(0.1, 5), lambda = "bic", intercept = TRUE,
    always.include = 2L, normalize = TRUE, solver = "eigen", method = 1L,
    parallelize = TRUE, ncores = 2L, nthreads = 1L,
    maxit = 12L, grouped = FALSE, group.maxit = 3L, relaxed = TRUE,
    prior.mean = matrix(0.2, 3, 2),
    thresh = 1e-6, tol = 1e-8,
    # Test the primitive backend dispatch independently of nuisance orchestration.
    control.solver = list(NaturalOrdering = TRUE, .nuisance = FALSE), verbose = TRUE, validation = NULL
  )
  fit <- do.call(l0glmFit, utils::modifyList(args, list(local.search=FALSE)))
  expect_setequal(names(fit$args), setdiff(names(args), "nonnegative"))
  expect_equal(fit$args, args[names(fit$args)])
})

test_that("OpenMP dispatch handles vector responses and family functions", {
  local_mocked_bindings(l0nnPois = function(...) list(args = list(...)))
  fit <- l0glmFit(local.search=FALSE, diag(4), 1:4, nonnegative = TRUE,
                   family = function() poisson(identity))
  expect_false(fit$args$relaxed)
  expect_false(fit$args$intercept)
  expect_identical(fit$args$family$family, "poisson")
  # l0glmFit retains its own public lambda default; dispatch does not change it.
  expect_identical(fit$args$lambda, 1)
})

test_that("fits outside the Poisson specialization use the general driver", {
  local_mocked_bindings(l0nnPois = function(...) stop("Unexpected dispatch"))
  base <- list(X = diag(4), y = c(4, 3, 2, 1), family = poisson(identity),
               nonnegative = TRUE, parallelize = FALSE, grouped = FALSE,
               relaxed = FALSE, lambda = 0.01)
  variants <- list(
    list(openmp = FALSE), list(nonnegative = FALSE),
    list(family = gaussian(identity)), list(family = poisson(log)),
    list(method = 2L), list(method = 3L), list(method = 4L),
    list(method = 5L), list(method = 6L), list(solver = "osqp"),
    list(control.solver = controlSolverGen("eigen", 2L)),
    list(control.solver = controlSolverGen("eigen", 5L)),
    list(control.solver = controlSolverGen("eigen", 1L, rowaug = FALSE))
  )
  for (variant in variants) {
    fit <- do.call(l0glmFit, utils::modifyList(utils::modifyList(base, variant), list(local.search=FALSE)))
    expect_equal(dim(fit$coefficients), c(4L, 1L))
    expect_true(all(is.finite(fit$coefficients)))
  }
  for (invalid in list(NA, "true", 1, logical(), c(TRUE, FALSE))) {
    expect_error(l0glmFit(local.search=FALSE, diag(2), 1:2, openmp = invalid),
                 "openmp must be TRUE or FALSE", fixed = TRUE)
  }
})

test_that("dispatched grouped fits agree with direct and R fits", {
  set.seed(20261012)
  X <- matrix(runif(60 * 12), 60, 12)
  beta <- matrix(0, 12, 3)
  beta[c(2, 6, 10), ] <- c(8, 12, 6)
  y <- matrix(rpois(180, as.vector(X %*% beta)), 60, 3)
  for (sparse in c(FALSE, TRUE)) {
    for (grouped in c(FALSE, TRUE)) {
      args <- list(X = Matrix::Matrix(X, sparse = sparse), y = y,
                   weights = seq(0.7, 1.2, length.out = 60),
                   offset = Matrix::Matrix(0.2, 60, 3),
                   lambda = "gic", grouped = grouped, relaxed = TRUE,
                   parallelize = FALSE, group.maxit = 2L, maxit = 15L)
      direct <- do.call(l0nnPois, utils::modifyList(args, list(local.search=FALSE)))
      dispatched <- do.call(l0glmFit, utils::modifyList(c(args, list(
        family = poisson(identity), nonnegative = TRUE)), list(local.search=FALSE)))
      general <- do.call(l0glmFit, utils::modifyList(c(args, list(
        family = poisson(identity), nonnegative = TRUE, openmp = FALSE)), list(local.search=FALSE)))
      expect_equal(without_fit_specification(dispatched), without_fit_specification(direct))
      expect_equal(as.matrix(dispatched$coefficients), as.matrix(general$coefficients),
                   tolerance = 1e-8)
    }
  }
})

test_that("l0nnPois defaults to the GIC penalty", {
  expect_identical(formals(l0nnPois)$lambda, "gic")
  implicit <- l0nnPois(local.search=FALSE, diag(6), c(0, 3, 0, 5, 0, 0), parallelize = FALSE)
  explicit <- l0nnPois(local.search=FALSE, diag(6), c(0, 3, 0, 5, 0, 0), lambda = "gic", parallelize = FALSE)
  expect_equal(without_fit_specification(implicit), without_fit_specification(explicit))
  expect_equal(implicit$init.lambda, log(6) * log(log(6)))
})

test_that("Poisson dispatch rejects invalid responses", {
  for (bad in list(c(-1, 2), c(NA, 2), c(Inf, 2))) {
    expect_error(l0glmFit(local.search=FALSE, diag(2), bad, family = poisson(identity), nonnegative = TRUE),
                 "finite and nonnegative")
    expect_error(l0nnPois(local.search=FALSE, diag(2), bad), "finite and nonnegative")
  }
})
