# Offset screening is an outer support search; every candidate fit starts afresh.
L0glm_isis <- function(X,y,family,weights,offset,nsis,full,nonnegative,niter,options,
                       nthreads=NULL,fixed_candidates=NULL,p_reference=NULL,working=TRUE) {
  if (!is.numeric(niter) || length(niter)!=1L || !is.finite(niter) ||
      niter<1 || niter!=floor(niter)) stop("niter must be a positive integer.",call.=FALSE)
  if (length(options) && (is.null(names(options)) || any(!nzchar(names(options))) ||
      anyDuplicated(names(options)) || any(!names(options)%in%names(formals(l0glmFit)))))
    stop("Use named l0glmFit arguments for ISIS fitting options.",call.=FALSE)
  started <- proc.time()[["elapsed"]]
  nthreads <- L0glm_sis_threads(nthreads);threads_used <- 1L
  kind <- L0glm_ext_kind(family);n <- nrow(X);p <- ncol(X)
  m <- if (identical(kind,"cox")) 1L else if (identical(kind,"multinomial")) family$nlp+1L else NCOL(y)
  args <- utils::modifyList(list(lambda="gic",start=NULL,ncores=1L,
    intercept=identical(kind,"multinomial") || identical(family$family,"binomial")),options,keep.null=TRUE)
  args$screen <- "none" # The outer search owns screening; candidate fits never recurse.
  args$local.search <- FALSE # The completed l0glmFit call owns support refinement.
  if (identical(family$family,"gaussian")) args$control.family$dispersion.calibration <- FALSE
  if (!is.logical(args$intercept) || length(args$intercept)!=1L || is.na(args$intercept))
    stop("intercept must be TRUE or FALSE.",call.=FALSE)
  if (identical(kind,"cox") && args$intercept) {
    warning("A Cox intercept is not identifiable; intercept was omitted.",call.=FALSE)
    args$intercept <- FALSE
  }
  added <- as.integer(args$intercept)
  design <- if(inherits(X,'L0glm_data'))L0glm_design_view(X,intercept=added==1L,
    names=if(is.null(colnames(X)))rep('',p)else colnames(X))else if (added) cbind(Intercept=1,X) else X
  included <- L0glm_mandatory(design,if (added) c(1L,args$always.include+1L) else args$always.include)
  mandatory <- included[included>added]-added
  if (identical(kind,"cox") && length(L0glm_intercepts(design)))
    stop("Remove constant/intercept columns from a Cox design.",call.=FALSE)
  p_total <- ncol(design)-length(included)
  if(!is.null(p_reference))p_total <- p_reference
  joint <- identical(kind,"cox") || identical(kind,"multinomial")
  w <- L0glm_ext_matrix(weights,n,if (joint) 1L else m,1,"weights")
  off <- L0glm_ext_matrix(offset,n,m,0,"offset")
  if (any(!is.finite(w)|w<0) || any(colSums(w)==0) || any(!is.finite(off)))
    stop("Each response needs positive finite weights; offsets must be finite.",call.=FALSE)
  n_ic <- if (identical(kind,"cox")) sum(w[,1L]*L0glm_ext_cox_response(y,n)$status) else
    if (is.null(kind)) n else sum(rowSums(w)>0)
  args$lambda <- L0glm_resolve_lambda(args$lambda,max(1L,p_total),max(2,n_ic))
  # Explicit coefficient arrays are in original coordinates; scalar one remains
  # a scalar so the selected fit can initialize in its normalized coordinates.
  expand <- function(value,name) {
    if (is.null(value) || name=="start" && length(value)==1L) return(value)
    if (length(value)==1L) return(matrix(value,ncol(design),m))
    B <- as.matrix(value)
    if (added && nrow(B)==p) B <- rbind(0,B)
    if (ncol(B)==1L && m>1L) B <- matrix(B,nrow(B),m)
    if (!identical(dim(B),c(ncol(design),as.integer(m))) || any(!is.finite(B)))
      stop(name," must have the original coefficient dimensions and finite values.",call.=FALSE)
    B
  }
  args$start <- expand(args$start,"start");args$prior.mean <- expand(args$prior.mean,"prior.mean")
  if (!is.null(args$start) && any(!is.finite(args$start))) stop("start must be finite.",call.=FALSE)
  allowed <- if (is.null(args$start)) rep(TRUE,p) else if (length(args$start)==1L)
    rep(args$start!=0,p) else rowSums(args$start[seq_len(p)+added,,drop=FALSE]!=0)>0
  allowed[mandatory] <- TRUE;eligible <- which(allowed)
  screen_X <- if (is.null(fixed_candidates) && length(eligible)<p) X[,eligible,drop=FALSE] else X
  if(working && m==1L && is.null(p_reference) && is.null(fixed_candidates)) {
    size <- L0glm_isis_cache_size(X,family,args,nonnegative,full,niter,nsis,mandatory,p_total,n_ic)
    if(size>0L)return(L0glm_isis_cached(X,y,family,nsis,niter,nthreads,size,
      list(args=args,added=added,mandatory=mandatory,included=included,design=design,
        w=w,off=off,p_total=p_total,n_ic=n_ic,started=started)))
  }
  B <- Matrix::Matrix(0,ncol(design),m,sparse=TRUE)
  selected <- mandatory;previous <- NULL;best <- NULL;history <- list();converged <- FALSE
  nuisance_history <- list(); quasi_estimated <- NULL
  for (iteration in seq_len(niter)) {
    if (!is.null(fixed_candidates)) {
      screen <- NULL
      candidates <- sort(unique(c(mandatory, fixed_candidates[allowed[fixed_candidates]])))
    } else if (length(eligible)) {
      active <- which(Matrix::rowSums(B!=0)>0)
      eta <- as.matrix(design[,active,drop=FALSE]%*%B[active,,drop=FALSE])+off
      screen <- sisGLM(screen_X,y,family,weights=w,offset=eta,nsis=min(nsis,length(eligible)),
        return_stats=full,nonnegative=nonnegative,nthreads=nthreads)
      threads_used <- max(threads_used,screen$nthreads)
      candidates <- sort(unique(c(selected,mandatory,eligible[screen$indices])))
    } else {screen <- NULL;candidates <- seq_len(p)}
    if (identical(candidates,previous)) {converged <- TRUE;break}
    rows <- if (added) c(1L,candidates+1L) else candidates
    fit_args <- args
    fit_args$validation <- L0glm_subset_validation(args$validation, rows)
    fit_args$always.include <- match(mandatory,candidates)
    for (name in c("start","prior.mean")) if (!is.null(args[[name]]) && length(args[[name]])>1L)
      fit_args[[name]] <- args[[name]][rows,,drop=FALSE]
    fit <- do.call(l0glmFit,c(list(X=X[,candidates,drop=FALSE],y=y,family=family,
      weights=w,offset=off,nonnegative=nonnegative),fit_args))
    if(isTRUE(args$control.solver$.screen.refit)) {
      refit_args <- c(list(X=X[,candidates,drop=FALSE],y=y,family=family,
        weights=w,offset=off,nonnegative=nonnegative),fit_args)
      control <- L0glm_local_control(if(is.null(args$control.local))list()else args$control.local,refit_args)
      if(L0glm_local_size(fit)<=control$size.max)
        fit <- L0glm_local_refine(fit,refit_args,control,support.only=TRUE)
    }
    if (any(fit$theta.estimated)) {
      nuisance_history[[iteration]] <- list(initial=fit$initialTheta, fitted=fit$theta)
      if (is.null(args$control.solver)) args$control.solver <- controlSolverGen(
        if (is.null(args$solver)) "eigen" else args$solver,
        if (is.null(args$method)) 1L else args$method)
      args$control.solver$.theta.start <- fit$theta
    } else {
      if (identical(family$family,"quasipoisson")) {
        # Use a common scale when comparing quasi-likelihoods across supports.
        if (is.null(quasi_estimated)) {
          quasi_estimated <- fit$dispersion.estimated
          args$dispersion <- fit$dispersion
        }
        fit$dispersion.estimated <- quasi_estimated
      } else if (any(fit$dispersion.estimated)) {
        args$dispersion <- ifelse(fit$dispersion.estimated, -fit$dispersion, fit$dispersion)
      }
      if (any(fit$dispersion.estimated))
        nuisance_history[[iteration]] <- list(initial=fit$initialDispersion, fitted=fit$dispersion)
    }
    score <- l0glmMetrics(fit,mu_floor=1e-8)
    gic <- get.IC(score$loglik,max(2,n_ic),max(1L,p_total),score$df)$gic
    entry <- summary(methods::as(methods::as(coef(fit),"generalMatrix"),"CsparseMatrix"))
    B <- Matrix::sparseMatrix(i=rows[entry$i],j=entry$j,x=entry$x,dims=c(ncol(design),m),
      dimnames=list(colnames(design),colnames(coef(fit))))
    selected <- which(Matrix::rowSums(B[seq_len(p)+added,,drop=FALSE]!=0)>0)
    history[[iteration]] <- data.frame(iteration,candidates=length(candidates),selected=length(setdiff(selected,mandatory)),
      df=score$df,gic,deviance=score$deviance)
    if(isTRUE(args$control.solver$.screen.refit))
      history[[iteration]]$support_refit <- isTRUE(fit$support.refit)
    criterion <- if (is.null(args$validation)) gic else
      L0glm_validation_loss(args$validation, B, state = list(theta = fit$theta))
    if (!is.null(args$validation)) history[[iteration]]$validation_deviance <- criterion
    if (is.null(best) || is.na(criterion) && is.na(best$criterion) ||
        !is.na(criterion) && (is.na(best$criterion) || criterion<best$criterion))
      best <- list(fit=fit,coefficients=B,candidates=candidates,rows=rows,screen=screen,gic=gic,
        criterion=criterion,iteration=iteration)
    previous <- candidates
    if (!is.null(fixed_candidates) || !length(eligible)) {converged <- TRUE;break}
  }
  fit <- best$fit;fit$coefficients <- best$coefficients;fit$X <- design
  fit$p <- p_total;fit$always.include <- included
  if (!is.null(fit$lambdas)) {
    penalties <- matrix(Inf,ncol(design),m)
    penalties[best$rows,] <- as.numeric(fit$lambdas)
    fit$lambdas <- if (is.null(dim(fit$lambdas))) as.numeric(penalties) else penalties
  }
  for (name in c("center","scale")) {
    value <- rep(if (name=="center") 0 else 1,ncol(design))
    value[best$rows] <- fit$preprocessing[[name]];fit$preprocessing[[name]] <- value
  }
  fit$preprocessing$p <- p_total
  fit$metrics <- l0glmMetrics(fit,mu_floor=1e-8)
  if (!is.null(fit$objective)) fit$objective <- fit$metrics$objective
  indices <- sort(unique(c(mandatory,which(Matrix::rowSums(fit$coefficients[seq_len(p)+added,,drop=FALSE]!=0)>0))))
  ranking <- stats <- NULL
  if (full && !is.null(best$screen)) {
    ranking <- eligible[best$screen$ranking]
    stats <- best$screen$stats;stats$feature <- eligible[stats$feature];stats$keep <- stats$feature%in%indices
  }
  list(indices=indices,top_statistics=NULL,ranking=ranking,stats=stats,nsis=length(indices),
    screen_size=nsis,family=family$family,link=family$link,theta=fit$theta,
    fit=fit,coefficients=fit$coefficients,candidates=best$candidates,lambda=args$lambda,
    history=do.call(rbind,history),nuisance_history=nuisance_history,best_iteration=best$iteration,iterations=length(history),
    converged=converged,seconds=proc.time()[["elapsed"]]-started,nthreads=threads_used)
}
