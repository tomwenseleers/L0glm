test_that("multichannel parallel fit matches serial fit", {
  ncores <- parallel::detectCores()
  skip_if(is.na(ncores) || ncores < 2L, "parallel test requires at least two cores")

  set.seed(42)
  n <- 18L
  p <- 10L
  m <- 4L

  X <- matrix(runif(n * p), n, p)
  beta <- matrix(0, p, m)
  beta[c(2L, 6L), ] <- c(1.5, 0.8)
  mu <- pmax(X %*% beta, 0.1)
  y <- matrix(rpois(n * m, as.vector(mu)), n, m)

  serial <- l0glmFit(
    X, y,control.solver=utils::modifyList(list(),list(.native=FALSE)),
    family = poisson(identity),
    lambda = "gic",
    nonnegative = TRUE,
    grouped = TRUE,ncores=1L,
    solver = "eigen",
    method = 1L,
    maxit = 10L,
    group.maxit = 2L)

  parallel <- l0glmFit(
    X, y,control.solver=utils::modifyList(list(),list(.native=FALSE)),
    family = poisson(identity),
    lambda = "gic",
    nonnegative = TRUE,
    grouped = TRUE,
    ncores = 2L,
    solver = "eigen",
    method = 1L,
    maxit = 10L,
    group.maxit = 2L)

  expect_identical(parallel$coefficients, serial$coefficients)
  expect_identical(parallel$lambdas, serial$lambdas)
  expect_identical(parallel$weights, serial$weights)
  expect_identical(parallel$z, serial$z)
  expect_identical(parallel$dispersion, serial$dispersion)
})

test_that("grouped relaxed fit keeps rows with cancelling channel coefficients", {
  X <- diag(3)
  y <- cbind(c(1, 0, 0), c(-1, 0, 0))

  fit <- l0glmFit(
    X, y,
    family = gaussian(identity),
    lambda = 0.01,
    nonnegative = FALSE,
    grouped = TRUE,ncores=1L,
    intercept = FALSE,
    normalize = FALSE,
    maxit = 10L,
    group.maxit = 2L)

  coefs <- as.matrix(fit$coefficients)
  lambdas <- as.matrix(fit$lambdas)
  expect_equal(coefs[1L, ], c(1, -1), tolerance = 1e-8)
  expect_true(all(coefs[-1L, ] == 0))
  expect_lt(max(abs(lambdas[1L, ])), 1e-25)
})

test_that("serial nthreads setting is restored after fit", {
  before <- l0glmThreads()

  sim <- simul(method = 4, n = 40L, p = 40L, s = 0.1, seed = 2)
  fit <- l0glmFit(
    sim$X, sim$y[, 1L, drop = FALSE],control.solver=utils::modifyList(list(),list(.native=FALSE)),
    family = poisson(identity),
    lambda = "gic",
    nonnegative = TRUE,
    grouped = FALSE,ncores=1L,
    nthreads = 1L,
    solver = "eigen",
    method = 1L)

  expect_s4_class(fit$coefficients, "dgCMatrix")
  expect_identical(l0glmThreads(), before)
})
