# L0glm 0.2.1

## Development changes

* Added `lambda = "mebic"` to `L0glm.fit()` and `L0nnpois()`, using
  `2 * log(p) * log(log(n))`, twice the GIC penalty.
* Information-criterion names are now consistently case-insensitive in both
  fitters, tuning and benchmark helpers. MEBIC is listed immediately after GIC.
* Added MEBIC to the fit metrics used for tuning. Added a shared
  information-criteria help topic with penalty formulas, usage guidance,
  original references and the GIC/SIC/HBIC relationship.
* Fixed metric calculation when true coefficients are not supplied, allowing
  information-criterion tuning on observed data without simulation truth.
* Removed `lower` and `upper` from `L0glm.fit()` and `L0nnpois()`. General box
  constraints are no longer part of either fitting interface.
* `L0glm.fit(nonnegative = TRUE)` constrains all coefficients, including any
  intercept and `always.include` terms. Binomial and quasibinomial intercepts
  remain unrestricted; columns of ones supplied in `X` are recognized too.
  The default `nonnegative = FALSE` allows coefficients of either sign.
* Removed `nonnegative` from `L0nnpois()`: its coefficients, including any
  intercept, are now always nonnegative. Remove this argument from existing
  calls, and use `L0glm.fit(nonnegative = FALSE)` for unrestricted fits.
* Applied the same constraint rules to initialization, grouped and relaxed
  fits, and serial and parallel execution. The NNLS ridge backend now handles
  unrestricted coefficients, including the binomial intercept.
* Updated help, examples and benchmarks to use the simplified interfaces.
